'use client'

import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Video, Home, ArrowRight } from 'lucide-react'
import Link from 'next/link'

export default function NotFound() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-xl border-0 bg-white/90 dark:bg-slate-800/90 backdrop-blur-sm">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-gradient-to-r from-emerald-500 to-teal-600 rounded-2xl flex items-center justify-center">
              <Video className="w-8 h-8 text-white" />
            </div>
          </div>
          <CardTitle className="text-2xl text-slate-800 dark:text-slate-100">
            صفحة غير موجودة
          </CardTitle>
          <CardDescription className="text-slate-600 dark:text-slate-400">
            عذراً، الصفحة التي تبحث عنها غير متوفرة
          </CardDescription>
        </CardHeader>
        <CardContent className="text-center">
          <div>
            <p className="text-slate-600 dark:text-slate-400 mb-6">
              يبدو أنك ضغطت على رابط خاطئ أو انتقلت إلى صفحة تم حذفها
            </p>
            <Link href="/">
              <Button className="bg-emerald-500 hover:bg-emerald-600 text-white w-full">
                <Home className="w-4 h-4 ml-2" />
                العودة للصفحة الرئيسية
                <ArrowRight className="w-4 h-4 mr-2" />
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}