import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "أداة إنشاء محتوى يوتيوب - محترفية وسريعة",
  description: "أداة احترافية لإنشاء عناوين وأوصاف وهاشتاجات يوتيوب جذابة. سريعة، سهلة الاستخدام، ومجانية تماماً. مثالية لمحتويي اليوتيوب.",
  keywords: ["يوتيوب", "محتوى يوتيوب", "عناوين يوتيوب", "أوصاف يوتيوب", "هاشتاجات يوتيوب", "أدوات يوتيوب", "محتوى عربي", "SEO يوتيوب"],
  authors: [{ name: "YouTube Content Tools" }],
  openGraph: {
    title: "أداة إنشاء محتوى يوتيوب الاحترافية",
    description: "أنشئ عناوين وأوصاف وهاشتاجات يوتيوب جذابة في ثوانٍ. أداة مجانية وسريعة لمحتويي اليوتيوب.",
    url: "https://your-domain.com",
    siteName: "أدوات يوتيوب",
    type: "website",
    locale: "ar_AR",
  },
  twitter: {
    card: "summary_large_image",
    title: "أداة إنشاء محتوى يوتيوب الاحترافية",
    description: "أنشئ عناوين وأوصاف وهاشتاجات يوتيوب جذابة في ثوانٍ",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  other: {
    "twitter:image": "https://your-domain.com/og-image.png",
    "og:image": "https://your-domain.com/og-image.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
