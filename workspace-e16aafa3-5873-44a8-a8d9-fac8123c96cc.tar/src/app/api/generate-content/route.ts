import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

export async function POST(request: NextRequest) {
  try {
    const { videoIdea, type } = await request.json()

    if (!videoIdea || !type) {
      return NextResponse.json(
        { error: 'Missing required parameters' },
        { status: 400 }
      )
    }

    const zai = await ZAI.create()

    let prompt = ''
    let response = ''

    switch (type) {
      case 'title':
        prompt = `أنت خبير في إنشاء عناوين يوتيوب جذابة وفعالة. بناءً على فكرة الفيديو التالية: "${videoIdea}"، قم بإنشاء عنوان واحد فقط جذاب ومثير للاهتمام يجعل المشاهدين يرغبون في النقر على الفيديو. العنوان يجب أن يكون:
        - قصير ومباشر (أقل من 60 حرفاً)
        - يحتوي على كلمات مفتاحية مهمة
        - يجذب الانتباه ويثير الفضول
        - مناسب لجمهور اليوتيوب العربي
        
        أرجع العنوان فقط بدون أي نص إضافي أو شرح.`
        break

      case 'description':
        prompt = `أنت خبير في كتابة أوصاف يوتيوب احترافية. بناءً على فكرة الفيديو التالية: "${videoIdea}"، قم بإنشاء وصف احترافي ومتكامل للفيديو يشمل:
        - مقدمة جذابة تلخص محتوى الفيديو
        - نقاط رئيسية يغطيها الفيديو
        - دعوة للتفاعل (لايك، اشتراك، تعليق)
        - هاشتاجات مناسبة (لكن لا تضعها في هذا الوصف)
        
        الوصف يجب أن يكون:
        - واضح وسهل القراءة
        - يحتوي على كلمات مفتاحية مهمة لتحسين محركات البحث
        - يشجع على المشاهدة والتفاعل
        - مناسب لجمهور اليوتيوب العربي
        
        أرجع الوصف كاملاً بصيغة جاهزة للنسخ واللصق.`
        break

      case 'hashtags':
        prompt = `أنت خبير في البحث عن هاشتاجات يوتيوب الرائجة والفعالة. بناءً على فكرة الفيديو التالية: "${videoIdea}"، قم بإنشاء قائمة من 15-20 هاشتاغاً مناسباً يشمل:
        - هاشتاجات عامة ورائجة في المجال
        - هاشتاجات خاصة بالمحتوى المحدد
        - هاشتاجات ذات حجم بحث متوسط إلى مرتفع
        - هاشتاجات مناسبة لجمهور اليوتيوب العربي
        
        أرجع الهاشتاجات فقط كقائمة مفصولة بمسافات، كل هاشتاغ يبدأ بـ #، بدون أي نص إضافي أو شرح.`
        break

      default:
        return NextResponse.json(
          { error: 'Invalid content type' },
          { status: 400 }
        )
    }

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'أنت مساعد احترافي متخصص في إنشاء محتوى يوتيوب عالي الجودة.'
        },
        {
          role: 'user',
          content: prompt
        }
      ],
      temperature: 0.7,
      max_tokens: type === 'title' ? 100 : type === 'hashtags' ? 300 : 500
    })

    const generatedContent = completion.choices[0]?.message?.content?.trim()

    if (!generatedContent) {
      return NextResponse.json(
        { error: 'Failed to generate content' },
        { status: 500 }
      )
    }

    if (type === 'hashtags') {
      // Split hashtags and clean them up
      const hashtags = generatedContent
        .split(/\s+/)
        .filter(tag => tag.startsWith('#') && tag.length > 1)
        .map(tag => tag.trim())
      
      return NextResponse.json({ hashtags })
    } else {
      return NextResponse.json({ content: generatedContent })
    }

  } catch (error) {
    console.error('Error generating content:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}