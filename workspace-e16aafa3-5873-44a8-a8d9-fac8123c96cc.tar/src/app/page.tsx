'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Copy, Download, Sparkles, Hash, Video, Wand2, Check, Zap, Shield, Star } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface GeneratedContent {
  title?: string
  description?: string
  hashtags?: string[]
}

export default function Home() {
  const [videoIdea, setVideoIdea] = useState('')
  const [generatedContent, setGeneratedContent] = useState<GeneratedContent>({})
  const [isGenerating, setIsGenerating] = useState(false)
  const [activeTab, setActiveTab] = useState('title')
  const [copiedStates, setCopiedStates] = useState({
    title: false,
    description: false,
    hashtags: false
  })
  const [mounted, setMounted] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    setMounted(true)
  }, [])

  const generateContent = async (type: 'title' | 'description' | 'hashtags') => {
    if (!videoIdea.trim()) {
      toast({
        title: "الرجاء إدخال فكرة الفيديو",
        description: "يجب أن تكتب فكرة الفيديو أولاً",
        variant: "destructive",
      })
      return
    }

    setIsGenerating(true)
    try {
      const response = await fetch('/api/generate-content', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          videoIdea,
          type,
        }),
      })

      if (!response.ok) {
        throw new Error('فشل في توليد المحتوى')
      }

      const data = await response.json()
      
      setGeneratedContent(prev => ({
        ...prev,
        [type]: type === 'hashtags' ? data.hashtags : data.content
      }))

      toast({
        title: "تم التوليد بنجاح",
        description: `تم توليد ${type === 'title' ? 'العنوان' : type === 'description' ? 'الوصف' : 'الهاشتاجات'} بنجاح`,
      })
    } catch (error) {
      toast({
        title: "خطأ في التوليد",
        description: "حدث خطأ أثناء توليد المحتوى، الرجاء المحاولة مرة أخرى",
        variant: "destructive",
      })
    } finally {
      setIsGenerating(false)
    }
  }

  const copyToClipboard = async (text: string, type: 'title' | 'description' | 'hashtags') => {
    try {
      // الطريقة الأولى: استخدام Clipboard API الحديث (الأفضل)
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(text)
        showSuccess(type)
        return
      }

      // الطريقة الثانية: استخدام document.execCommand (للمتصفحات القديمة)
      try {
        const textArea = document.createElement('textarea')
        textArea.value = text
        
        // إخفاء العنصر
        textArea.style.position = 'fixed'
        textArea.style.left = '-999999px'
        textArea.style.top = '-999999px'
        textArea.style.opacity = '0'
        
        document.body.appendChild(textArea)
        textArea.focus()
        textArea.select()
        
        // محاولة النسخ
        const successful = document.execCommand('copy')
        document.body.removeChild(textArea)
        
        if (successful) {
          showSuccess(type)
          return
        }
      } catch (execError) {
        console.warn('execCommand failed:', execError)
      }

      // الطريقة الثالثة: استخدام navigator.clipboard بدون التحقق من السياق الآمن
      try {
        await navigator.clipboard.writeText(text)
        showSuccess(type)
        return
      } catch (clipboardError) {
        console.warn('clipboard API failed:', clipboardError)
      }

      // إذا فشلت كل الطرق، نعرض رسالة خطأ واضحة
      throw new Error('جميع طرق النسخ فشلت')

    } catch (error) {
      console.error('Error copying to clipboard:', error)
      
      // نحاول نسخ النص إلى وحدة التحكم كحل أخير
      console.log('=== المحتوى الذي فشل نسخه ===')
      console.log(text)
      console.log('=== نهاية المحتوى ===')
      
      toast({
        title: "فشل النسخ التلقائي",
        description: "تم نسخ المحتوى إلى وحدة التحكم (Console) - اضغط F12 لعرضه",
        variant: "destructive",
        action: (
          <div className="text-xs">
            اضغط Ctrl+V للصق
          </div>
        ),
      })
    }
  }

  const showSuccess = (type: 'title' | 'description' | 'hashtags') => {
    setCopiedStates(prev => ({ ...prev, [type]: true }))
    toast({
      title: "تم النسخ",
      description: "تم نسخ المحتوى إلى الحافظة بنجاح",
    })
    
    // إعادة تعيين حالة النسخ بعد ثانيتين
    setTimeout(() => {
      setCopiedStates(prev => ({ ...prev, [type]: false }))
    }, 2000)
  }

  const downloadContent = (type: string) => {
    let content = ''
    let filename = ''
    
    switch (type) {
      case 'title':
        content = generatedContent.title || ''
        filename = 'youtube-title.txt'
        break
      case 'description':
        content = generatedContent.description || ''
        filename = 'youtube-description.txt'
        break
      case 'hashtags':
        content = generatedContent.hashtags?.join(' ') || ''
        filename = 'youtube-hashtags.txt'
        break
    }

    const blob = new Blob([content], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = filename
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    toast({
      title: "تم التحميل",
      description: `تم تحميل ${type === 'title' ? 'العنوان' : type === 'description' ? 'الوصف' : 'الهاشتاجات'} بنجاح`,
    })
  }

  if (!mounted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-emerald-500"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      {/* Header */}
      <header className="border-b border-slate-200 dark:border-slate-700 bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-r from-emerald-500 to-teal-600 rounded-lg flex items-center justify-center">
                <Video className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-slate-800 dark:text-slate-100">
                  أدوات يوتيوب الاحترافية
                </h1>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  أنشئ محتوى يوتيوب مميز في ثوانٍ
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="secondary" className="bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200">
                <Zap className="w-3 h-3 ml-1" />
                مجاني
              </Badge>
              <Badge variant="secondary" className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
                <Shield className="w-3 h-3 ml-1" />
                آمن
              </Badge>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 mb-6 bg-gradient-to-r from-emerald-500 to-teal-600 rounded-2xl shadow-lg">
            <Video className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl font-bold text-slate-800 dark:text-slate-100 mb-4">
            أداة إنشاء محتوى يوتيوب
          </h1>
          <p className="text-xl text-slate-600 dark:text-slate-400 mb-8 max-w-3xl mx-auto">
            احترف إنشاء العناوين والأوصاف والهاشتاجات لفيديوهاتك بأدوات احترافية وسريعة. مجانية تماماً وسهلة الاستخدام.
          </p>

          {/* Features */}
          <div className="flex flex-wrap justify-center gap-6 mb-8">
            <div className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
              <Star className="w-5 h-5 text-emerald-500" />
              <span>عناوين جذابة</span>
            </div>
            <div className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
              <Star className="w-5 h-5 text-emerald-500" />
              <span>أوصاف احترافية</span>
            </div>
            <div className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
              <Star className="w-5 h-5 text-emerald-500" />
              <span>هاشتاجات رائجة</span>
            </div>
            <div className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
              <Star className="w-5 h-5 text-emerald-500" />
              <span>نسخ فوري</span>
            </div>
          </div>
        </div>

        {/* Main Input */}
        <div className="max-w-4xl mx-auto mb-12">
          <Card className="shadow-xl border-0 bg-white/90 dark:bg-slate-800/90 backdrop-blur-sm">
            <CardHeader className="text-center">
              <CardTitle className="flex items-center justify-center gap-2 text-2xl text-slate-800 dark:text-slate-100">
                <Sparkles className="w-6 h-6 text-emerald-500" />
                ابدأ بإنشاء محتوى يوتيوب احترافي
              </CardTitle>
              <CardDescription className="text-lg text-slate-600 dark:text-slate-400">
                اكتب فكرة الفيديو الخاص بك وسنقوم بإنشاء المحتوى المناسب لك
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="اكتب فكرة الفيديو هنا... مثال: فيديو عن وصفات طعام سريعة وسهلة للعمل"
                value={videoIdea}
                onChange={(e) => setVideoIdea(e.target.value)}
                className="min-h-[140px] resize-none border-slate-200 dark:border-slate-700 focus:border-emerald-500 dark:focus:border-emerald-400 text-lg"
              />
            </CardContent>
          </Card>
        </div>

        {/* Tools */}
        <div className="max-w-6xl mx-auto">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-12 bg-slate-100 dark:bg-slate-800 p-2 rounded-xl shadow-lg">
              <TabsTrigger 
                value="title" 
                className="flex items-center gap-3 data-[state=active]:bg-emerald-500 data-[state=active]:text-white text-lg py-3"
              >
                <Wand2 className="w-5 h-5" />
                العنوان
              </TabsTrigger>
              <TabsTrigger 
                value="description" 
                className="flex items-center gap-3 data-[state=active]:bg-emerald-500 data-[state=active]:text-white text-lg py-3"
              >
                <Video className="w-5 h-5" />
                الوصف
              </TabsTrigger>
              <TabsTrigger 
                value="hashtags" 
                className="flex items-center gap-3 data-[state=active]:bg-emerald-500 data-[state=active]:text-white text-lg py-3"
              >
                <Hash className="w-5 h-5" />
                الهاشتاجات
              </TabsTrigger>
            </TabsList>

            {/* Title Generator */}
            {activeTab === 'title' && (
              <Card className="shadow-xl border-0 bg-white/90 dark:bg-slate-800/90 backdrop-blur-sm">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-3 text-2xl text-slate-800 dark:text-slate-100">
                        <Wand2 className="w-6 h-6 text-emerald-500" />
                        مولد العناوين الاحترافي
                      </CardTitle>
                      <CardDescription className="text-lg text-slate-600 dark:text-slate-400">
                        قم بإنشاء عنوان جذاب ومثير للاهتمام لفيديو اليوتيوب الخاص بك
                      </CardDescription>
                    </div>
                    <Button
                      onClick={() => generateContent('title')}
                      disabled={isGenerating}
                      className="bg-emerald-500 hover:bg-emerald-600 text-white px-6 py-3 text-lg"
                    >
                      {isGenerating ? 'جاري التوليد...' : 'توليد العنوان'}
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {generatedContent.title && (
                    <div className="space-y-6">
                      <div className="p-6 bg-slate-50 dark:bg-slate-900 rounded-xl border-2 border-slate-200 dark:border-slate-700">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1">
                            <h3 className="text-xl font-semibold text-slate-800 dark:text-slate-100 mb-3">
                              العنوان المولد:
                            </h3>
                            <p className="text-lg text-slate-700 dark:text-slate-300 leading-relaxed">
                              {generatedContent.title}
                            </p>
                          </div>
                          <div className="flex flex-col gap-2">
                            <Button
                              onClick={() => copyToClipboard(generatedContent.title!, 'title')}
                              disabled={copiedStates.title}
                              size="sm"
                              className="bg-emerald-500 hover:bg-emerald-600 text-white"
                            >
                              {copiedStates.title ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                            </Button>
                            <Button
                              onClick={() => downloadContent('title')}
                              variant="outline"
                              size="sm"
                              className="border-slate-200 dark:border-slate-700"
                            >
                              <Download className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Description Generator */}
            {activeTab === 'description' && (
              <Card className="shadow-xl border-0 bg-white/90 dark:bg-slate-800/90 backdrop-blur-sm">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-3 text-2xl text-slate-800 dark:text-slate-100">
                        <Video className="w-6 h-6 text-emerald-500" />
                        مولد الأوصاف الاحترافي
                      </CardTitle>
                      <CardDescription className="text-lg text-slate-600 dark:text-slate-400">
                        قم بإنشاء وصف احترافي ومتكامل لفيديو اليوتيوب الخاص بك
                      </CardDescription>
                    </div>
                    <Button
                      onClick={() => generateContent('description')}
                      disabled={isGenerating}
                      className="bg-emerald-500 hover:bg-emerald-600 text-white px-6 py-3 text-lg"
                    >
                      {isGenerating ? 'جاري التوليد...' : 'توليد الوصف'}
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {generatedContent.description && (
                    <div className="space-y-6">
                      <div className="p-6 bg-slate-50 dark:bg-slate-900 rounded-xl border-2 border-slate-200 dark:border-slate-700">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1">
                            <h3 className="text-xl font-semibold text-slate-800 dark:text-slate-100 mb-3">
                              الوصف المولد:
                            </h3>
                            <p className="text-lg text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-line">
                              {generatedContent.description}
                            </p>
                          </div>
                          <div className="flex flex-col gap-2">
                            <Button
                              onClick={() => copyToClipboard(generatedContent.description!, 'description')}
                              disabled={copiedStates.description}
                              size="sm"
                              className="bg-emerald-500 hover:bg-emerald-600 text-white"
                            >
                              {copiedStates.description ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                            </Button>
                            <Button
                              onClick={() => downloadContent('description')}
                              variant="outline"
                              size="sm"
                              className="border-slate-200 dark:border-slate-700"
                            >
                              <Download className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Hashtags Generator */}
            {activeTab === 'hashtags' && (
              <Card className="shadow-xl border-0 bg-white/90 dark:bg-slate-800/90 backdrop-blur-sm">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-3 text-2xl text-slate-800 dark:text-slate-100">
                        <Hash className="w-6 h-6 text-emerald-500" />
                        مولد الهاشتاجات الاحترافي
                      </CardTitle>
                      <CardDescription className="text-lg text-slate-600 dark:text-slate-400">
                        قم بإنشاء هاشتاجات رائجة ومناسبة لفيديو اليوتيوب الخاص بك
                      </CardDescription>
                    </div>
                    <Button
                      onClick={() => generateContent('hashtags')}
                      disabled={isGenerating}
                      className="bg-emerald-500 hover:bg-emerald-600 text-white px-6 py-3 text-lg"
                    >
                      {isGenerating ? 'جاري التوليد...' : 'توليد الهاشتاجات'}
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {generatedContent.hashtags && generatedContent.hashtags.length > 0 && (
                    <div className="space-y-6">
                      <div className="p-6 bg-slate-50 dark:bg-slate-900 rounded-xl border-2 border-slate-200 dark:border-slate-700">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1">
                            <h3 className="text-xl font-semibold text-slate-800 dark:text-slate-100 mb-3">
                              الهاشتاجات المولدة:
                            </h3>
                            <div className="flex flex-wrap gap-2">
                              {generatedContent.hashtags.map((hashtag, index) => (
                                <Badge
                                  key={index}
                                  variant="secondary"
                                  className="bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200 text-sm py-1 px-3"
                                >
                                  {hashtag}
                                </Badge>
                              ))}
                            </div>
                          </div>
                          <div className="flex flex-col gap-2">
                            <Button
                              onClick={() => copyToClipboard(generatedContent.hashtags!.join(' '), 'hashtags')}
                              disabled={copiedStates.hashtags}
                              size="sm"
                              className="bg-emerald-500 hover:bg-emerald-600 text-white"
                            >
                              {copiedStates.hashtags ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                            </Button>
                            <Button
                              onClick={() => downloadContent('hashtags')}
                              variant="outline"
                              size="sm"
                              className="border-slate-200 dark:border-slate-700"
                            >
                              <Download className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </Tabs>
        </div>

        {/* Footer */}
        <footer className="mt-16 py-8 border-t border-slate-200 dark:border-slate-700">
          <div className="text-center">
            <p className="text-slate-600 dark:text-slate-400">
              © 2024 أدوات يوتيوب الاحترافية. جميع الحقوق محفوظة.
            </p>
            <p className="text-sm text-slate-500 dark:text-slate-500 mt-2">
              مجاني تماماً • آمن وموثوق • سهل الاستخدام
            </p>
          </div>
        </footer>
      </div>
    </div>
  )
}