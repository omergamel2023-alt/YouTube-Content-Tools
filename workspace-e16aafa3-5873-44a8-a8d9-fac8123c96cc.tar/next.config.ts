import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // تحسينات الأداء
  compress: true,
  poweredByHeader: false,
  
  // تحسينات الصور
  images: {
    formats: ['image/webp', 'image/avif'],
    deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
    imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
  },
  
  // تحسينات للإنتاج
  typescript: {
    ignoreBuildErrors: false,
  },
  
  // تحسينات ESLint
  eslint: {
    ignoreDuringBuilds: false,
  },
  
  // تحسينات التوجيه
  async redirects() {
    return [
      {
        source: '/youtube-tools',
        destination: '/',
        permanent: true,
      },
      {
        source: '/youtube-content-creator',
        destination: '/',
        permanent: true,
      },
    ];
  },
  
  // تحسينات الرأس
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          {
            key: 'X-Frame-Options',
            value: 'DENY',
          },
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff',
          },
          {
            key: 'Referrer-Policy',
            value: 'origin-when-cross-origin',
          },
        ],
      },
    ];
  },
  
  // إعدادات التطوير
  reactStrictMode: true,
  webpack: (config, { dev }) => {
    if (dev) {
      config.watchOptions = {
        ignored: ['**/*'],
      };
    }
    
    // تحسينات الأداء
    config.optimization = {
      ...config.optimization,
      splitChunks: {
        chunks: 'all',
        cacheGroups: {
          vendor: {
            test: /[\\/]node_modules[\\/]/,
            name: 'vendors',
            chunks: 'all',
            priority: 10,
          },
          common: {
            name: 'common',
            minChunks: 2,
            chunks: 'all',
            priority: 5,
          },
        },
      },
    };
    
    return config;
  },
};

export default nextConfig;
